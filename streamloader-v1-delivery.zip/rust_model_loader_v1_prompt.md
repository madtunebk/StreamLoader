# Agent task: Rust model loader v1 — mmap SafeTensors, logical transformer blocks

Implement this project, test it, and deliver a reviewable source ZIP. Do not stop at a design proposal. Use English for code/docs and a concise Romanian delivery summary.

## Goal and boundary

Build a Rust library plus CLI that opens ORIGINAL SafeTensors model files, indexes tensor byte ranges, groups tensors logically into transformer blocks, and exposes the requested block without exporting separate block files or copying the entire checkpoint into a Rust heap buffer.

First milestone is CPU-only, real and independently usable. No Python, PyTorch, CUDA toolkit, or GPU should be required to build/run v1. This is a weight loader, NOT an inference engine. Do not claim image generation, GPU streaming, pinned memory, or PyTorch compatibility has been implemented unless it actually has; those are later milestones. Do not implement speculative GPU scaffolding or a mock server to imply otherwise.

## Context

Target user has 64 GB RAM and two RTX 3060 12 GB GPUs. Large diffusion transformer checkpoints can be around 28 GB. Primary target is DiT, initially FLUX-style block names; general tensor loading should remain architecture-independent. No UNet execution work is needed.

Existing Python reference archives, if supplied:
- `true_stream(1).zip`: older loader/streamer and model helpers.
- `caca.zip`: newer block streaming, shared RAM cache, pinned experiments, and FLUX.2 ring attention.

These are references, not dependencies or proof of performance. Do not execute supplied scripts just to inspect them. The existing loader expects `block_*/tensors.safetensors`; the new loader must REMOVE this prerequisite and read original checkpoints instead.

Observed source-level issues to avoid carrying forward:
- PinnedBlockCache retains a new pinned copy while RamBlockCache still owns the pageable copy; its comment claiming replacement does not implement replacement.
- n_resident in the reference streamer retains recent blocks temporarily, not across complete forward passes.
- Shared weights are injected/cleared repeatedly.
- Ring mode creates separate RAM caches in separate processes.
- The source documents pinned staging regressions. Do not assert pinning is automatically faster; referenced benchmark reports were not in the supplied archives.

Rust is chosen for explicit ownership, byte-range access, and future scheduling. Changing language alone is NOT a speedup claim.

## Required inputs

Support:
1. A single `.safetensors` file.
2. A SafeTensors index JSON with `weight_map`, resolving tensor names to shard filenames.
3. A local directory: select an unambiguous SafeTensors index, or accept an explicitly supplied index filename; if no index exists, discover SafeTensors files deterministically and reject duplicate tensor names. Do not silently combine several independent model components. For ambiguous directory layouts, give an actionable error requesting the component/index path.

Accept real diffusion naming such as `diffusion_pytorch_model.safetensors.index.json`; do not hard-code only `model.safetensors.index.json`. Do not download models. If user weights are unavailable, complete the implementation with Rust-generated fixtures and explicitly mark real-model validation as pending.

## Implementation requirements

Use a maintained Rust SafeTensors parser/validator and `memmap2` where suitable. Verify actual dependency APIs using the selected versions' source/docs; do not invent APIs. Include Cargo.lock. Choose a small, justified dependency set.

- Open checkpoint files read-only and retain mappings with explicit ownership.
- Parse/validate metadata without materializing tensor payloads in owned Vec buffers.
- Build owned descriptors: tensor name, dtype, shape, shard ID/path, data offset, byte length.
- SafeTensors offsets are relative to the data section, not the file start. Handle the format's header prefix correctly; use checked arithmetic throughout.
- Expose byte views with lifetimes tied to the mapping/loader, or equivalent owned handles retaining the backing. Never return a dangling slice, transmute lifetimes, or make a self-referential struct using unchecked lifetime tricks.
- Avoid casting arbitrary byte slices into aligned typed slices. Preserve exact dtype and bytes. Explicitly reject unsupported representations instead of silently converting them.
- Validate bounds, shapes and payload lengths using format rules; handle scalars and zero-length tensors. Bound unreasonable header allocation/metadata size with a documented configurable limit.
- Reject malformed/truncated files, inconsistent index mappings, missing shards, duplicate tensor names, and arithmetic overflow with contextual errors.
- Constrain index shard paths to the selected checkpoint root; reject absolute paths and traversal, including symlink escape. Document this resolution rule.
- Document mmap's unsafe contract: backing files must not be modified/truncated during use. Read-only mapping does not prevent another process changing the file. Annotate every unsafe block with its actual preconditions.
- Cache identity must include the source model if any caching is introduced. Do not key globally only by `transformer_blocks.0`.

## Logical block grouping

Provide deterministic prefix grouping for these initial conventions:
- `transformer_blocks.<integer>.*`
- `single_transformer_blocks.<integer>.*`
- `blocks.<integer>.*`
- `layers.<integer>.*`

Allow an explicit optional model prefix, e.g. `model.layers.0.*`, without silently stripping unrelated portions of names. Provide a simple documented override/config for ordered block-family prefixes, rather than a complicated plugin system.

For the FLUX preset, list transformer_blocks first, then single_transformer_blocks, sorting indices numerically (2 before 10). Do not infer execution order from arbitrary digits anywhere in tensor names. Report unmatched tensors as `shared/unassigned`; this is a grouping label, not proof they should all remain GPU-resident.

A block can span discontiguous file regions and several shards. Return descriptors/views for all tensors in that block. Never assume a block is one contiguous range. Preserve exact original tensor names. Listing a block must not require reading all of its payload.

## Public library and CLI

Names may change for idiomatic Rust, but implement these capabilities:
- Open/index a model.
- List tensor metadata and logical blocks.
- Get a tensor byte view by exact name.
- Get all tensor descriptors/views belonging to an exact block ID.
- Explicitly copy a selected block into a caller-owned buffer with a returned offset layout, if offered; keep this distinct from the zero-copy view API and report copied bytes. Do not make copying mandatory for block access.

Suggested CLI surface:

```bash
cargo run --release -- inspect /path/to/transformer --json
cargo run --release -- blocks /path/to/transformer --preset flux --json
cargo run --release -- block /path/to/transformer --id transformer_blocks.12 --preset flux --json
cargo run --release -- verify /path/to/transformer --block transformer_blocks.12 --preset flux --json
```

`inspect`, `blocks`, and `block` report metadata. `verify` must actually touch the selected payload bytes and emit deterministic per-tensor checksums, with a documented algorithm; it must not just hash names/metadata. Nonexistent block/tensor returns a nonzero exit code. Provide a tensor-selection equivalent for unassigned tensors. JSON output must be machine-readable, with diagnostics on stderr.

## Memory and performance honesty

mmap is lazy virtual-memory mapping. It does NOT mean the whole file is resident, pinned, or on GPU. Mapping 28 GB is not the same as allocating 28 GB anonymous heap memory. File-backed pages may still consume physical RAM and can be evicted/re-read. Do not advertise SSD-to-GPU zero-copy or no I/O.

The v1 zero-copy claim may refer ONLY to application-level borrowed CPU byte views. Payload verification necessarily reads pages and may cause disk I/O.

Provide a small reproducible benchmark command or Rust example that separately measures:
- Open/header indexing time.
- Metadata block lookup time.
- Reading/checksumming selected block bytes, with total bytes processed.
- Repeated passes, labeled first-observed and subsequent; do not claim a cold OS cache unless controlled.

Checksumming time is not raw disk bandwidth or CUDA transfer performance. If reporting RSS, file-backed memory, faults, or read_bytes on Linux, label the metric and limitations. Do not demand privileged cache flushing. Do not infer RAM savings solely from virtual mapping size. No made-up hardware numbers or GPU speedups.

## Required correctness tests

Generate small deterministic SafeTensors fixtures in Rust; no Python fixture generator is required.

Test at least:
1. Known tensor bytes/shapes/dtypes in one file.
2. Multiple shards with valid weight_map.
3. One logical block spanning shards and nonadjacent byte ranges.
4. Numeric ordering (2 versus 10) and FLUX double/single-family order.
5. Shared/unassigned tensors and explicit prefix selection.
6. Exact block matching: block 1 does not include block 10.
7. Missing shard/tensor and inconsistent index mappings.
8. Truncation, malformed metadata/offsets, duplicate names, overflow, and path escape.
9. Empty/scalar tensors consistent with supported SafeTensors format.
10. Multiple model instances with identical tensor names but different data.
11. Safe ownership/lifetimes and concurrent read access if the public API claims it.
12. CLI JSON, verification checksum against known bytes, and nonzero errors.

Do not create a fake huge checkpoint and treat sparse-file behavior as a real 28 GB model benchmark. Tiny fixture success is correctness evidence only.

## Explicitly deferred architecture

Keep the core reusable so a later milestone can add:
- RAM budget policies and a single shared backing across GPU workers.
- Direct population of final pinned buffers (without retaining an entire duplicate pageable tensor cache), or bounded staging, compared by measurement.
- CUDA transfer/compute events, reusable VRAM buffers, persistent resident blocks, and prefetch scheduling.
- A thin Python binding in the same process, later interoperating with PyTorch tensor ownership and streams.

Do NOT implement these now. Full-pinned loading and mmap-only views are distinct memory policies, not magic simultaneous zero-copy behavior. A CPU copy into pinned memory plus a GPU copy must be counted honestly. Buffer reuse later must wait for the appropriate GPU completion events; Rust ownership alone does not track asynchronous CUDA completion.

## Deliverables and completion gate

Deliver:
- A clean Rust crate/workspace with library and CLI, Cargo.toml and Cargo.lock.
- README with exact runnable commands, supported inputs, memory semantics, and limitations.
- Tests/fixture generation and benchmark example or command.
- DESIGN.md explaining descriptor ownership, block grouping, and future integration boundaries.
- VALIDATION.md recording exact commands and actual outcomes, environment/compiler versions, and a clear distinction between fixture-tested, real-model-tested, and not tested.
- A source ZIP, excluding target/, model weights, virtualenvs, caches, credentials, and unrelated uploaded code. Include source, lockfile, documentation, and fixtures or fixture generator. Inspect ZIP contents before delivering.

Run formatting, cargo check, meaningful tests, and clippy where available. Resolve real failures; do not hide warnings globally to achieve a clean check. If network/dependencies/toolchain prevent validation, state the exact blocker and do not label the build successful.

The acceptance bar: real original SafeTensors files can be indexed and selected blocks read correctly without pre-splitting checkpoint files or allocating a model-sized heap copy. No pretend inference, no simulated GPU success, and no unmeasured speed claims. Make reasonable implementation choices and finish the bounded v1 without repeatedly requesting permission.
